# CURRENT TASK — 示例

## 当前阶段

Stage 7D — Kimi Billing 接口探测。

## 任务档位

S

## 本轮唯一目标

修复 `probeEndpoints` 在主线程执行网络请求导致的 `NetworkOnMainThreadException`。

## 已知事实

1. Billing 探测逻辑已经存在；
2. 接口列表和请求参数本轮保持不变；
3. 异常已明确为网络请求运行在主线程；
4. 本轮不处理 Widget 显示和 UI。

## 已确认原因

`probeEndpoints` 从主线程直接执行同步网络请求，Android 因此抛出 `NetworkOnMainThreadException`。

## 冻结事项

- 不重新摸排 Billing 接口；
- 不修改接口列表、请求参数和结果含义；
- 不更换现有网络库；
- 不改变 Widget 数据结构。

## 允许读取

- `CURRENT_TASK.md`
- `AGENTS.md`
- `<包含 probeEndpoints 的精确源文件路径>`

## 允许修改

- `<包含 probeEndpoints 的精确源文件路径>`

## 允许工具

- 精确读取上述文件；
- 修改目标源文件；
- 查看本轮 diff；
- 执行唯一验证脚本。

## 允许命令

```bash
.agent/skills/focused-android-executor/scripts/verify-debug.sh
```

## 禁止事项

- 不扫描整个项目；
- 不重新搜索 Billing 端点；
- 不新增协程库或其他依赖；
- 不重构网络层；
- 不修改 Widget、Gradle 或 Manifest；
- 不提交或推送 Git。

## 完成标准

1. 网络请求不再运行于主线程；
2. 原有 Billing 探测逻辑保持不变；
3. 本轮只修改目标源文件；
4. Debug APK 编译成功；
5. APK 覆盖安装成功；
6. 汇报人工测试步骤后停止。

## 人工验收方法

1. 打开配置页面；
2. 触发 Billing 探测；
3. 确认应用不再因 `NetworkOnMainThreadException` 闪退；
4. 确认返回结果或中文错误提示正常显示。

## 熔断条件

- 编译错误指向与本轮无关的模块；
- 需要新增依赖才能继续；
- 同一错误在无新修改时重复；
- 超过 S 档预算。
