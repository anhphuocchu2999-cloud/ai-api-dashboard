#!/usr/bin/env bash
# Install this skill into a target project's .agent/skills directory.
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="${1:-$(pwd)}"
TARGET_DIR="$TARGET_ROOT/.agent/skills/focused-android-executor"

SOURCE_REAL="$(cd "$SOURCE_DIR" && pwd -P)"
TARGET_REAL_PARENT="$(mkdir -p "$(dirname "$TARGET_DIR")" && cd "$(dirname "$TARGET_DIR")" && pwd -P)"
TARGET_REAL="$TARGET_REAL_PARENT/$(basename "$TARGET_DIR")"

if [[ "$SOURCE_REAL" == "$TARGET_REAL" ]]; then
  chmod +x "$TARGET_DIR/scripts/verify-debug.sh" 2>/dev/null || true
  echo "INSTALLED=$TARGET_DIR"
  echo "STATUS=already_in_place"
  exit 0
fi

rm -rf "$TARGET_DIR"
mkdir -p "$TARGET_DIR"
cp -R "$SOURCE_DIR"/. "$TARGET_DIR"/
rm -f "$TARGET_DIR/install.sh"
chmod +x "$TARGET_DIR/scripts/verify-debug.sh" 2>/dev/null || true

echo "INSTALLED=$TARGET_DIR"
echo "NEXT=Copy templates/CURRENT_TASK.md to the project root as CURRENT_TASK.md and fill in the whitelist."
