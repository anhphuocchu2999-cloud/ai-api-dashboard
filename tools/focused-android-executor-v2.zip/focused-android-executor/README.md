# focused-android-executor v2

一个用于已有 Android 项目的受控执行 Skill，重点解决：

- 工具调用过多；
- 重复扫描和重复读取；
- 上下文越来越长；
- 简单任务被拆成很多模型回合；
- 编译、找 APK、安装被拆成多次工具调用；
- 任务完成后仍继续优化或进入下一阶段。

## V2 新增能力

1. **文件、工具和命令白名单**：未列入 `CURRENT_TASK.md` 的动作默认禁止；
2. **S / M / L 分档预算**：按任务复杂度限制读取、修改、调用和验证次数；
3. **无进展熔断**：连续两次无新证据或同一错误空转时立即停止；
4. **一次性验证脚本**：把构建、日志截断、APK 定位和覆盖安装合并成一次调用；
5. **输出压缩**：只报告 diff、关键错误、验证结果和人工验收；
6. **效率统计**：每轮记录读取文件、修改文件、工具调用和验证次数。

## 推荐目录

将整个目录放入项目：

```text
.agent/skills/focused-android-executor/
```

项目根目录保留：

```text
AGENTS.md
PROJECT.md
CURRENT_TASK.md
```

其中 `CURRENT_TASK.md` 可从：

```text
.agent/skills/focused-android-executor/templates/CURRENT_TASK.md
```

复制后填写。

## 安装

在已下载的 Skill 目录中执行：

```bash
./install.sh /path/to/android-project
```

不传路径时安装到当前目录：

```bash
./install.sh
```

也可以直接把本目录复制到目标项目的 `.agent/skills/` 下。

## 使用

```text
使用 focused-android-executor Skill 执行 CURRENT_TASK.md。
只使用任务单白名单中的文件、工具和命令；按任务档位执行；触发完成条件或熔断条件后立即停止。
```

## 验证脚本

Linux / Android shell / macOS：

```bash
.agent/skills/focused-android-executor/scripts/verify-debug.sh
```

仅编译、不安装：

```bash
.agent/skills/focused-android-executor/scripts/verify-debug.sh "$(pwd)" build-only
```

Windows PowerShell：

```powershell
powershell -ExecutionPolicy Bypass -File .agent/skills/focused-android-executor/scripts/verify-debug.ps1
```

脚本成功时只输出：

```text
RESULT=OK
BUILD=SUCCESS
INSTALL=SUCCESS
APK=<path>
```

失败时只输出步骤、原因和最后 100 行相关日志。

## 文件说明

```text
SKILL.md                              核心执行规则
templates/CURRENT_TASK.md             每轮任务白名单模板
examples/network-main-thread-fix.md   当前主线程网络异常示例
scripts/verify-debug.sh               Bash 一次性构建安装脚本
scripts/verify-debug.ps1              PowerShell 一次性构建安装脚本
install.sh                            安装到目标项目的脚本
```
