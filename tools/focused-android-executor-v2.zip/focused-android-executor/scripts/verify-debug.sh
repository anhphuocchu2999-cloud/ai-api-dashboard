#!/usr/bin/env bash
# Build a Debug APK, print only the last 100 log lines on failure,
# locate the newest Debug APK, and install it with adb install -r.
set -u
set -o pipefail

PROJECT_ROOT="${1:-$(pwd)}"
MODE="${2:-install}" # install | build-only
GRADLE_TASK="${GRADLE_TASK:-assembleDebug}"

cd "$PROJECT_ROOT" 2>/dev/null || {
  echo "RESULT=ERROR"
  echo "STEP=PREPARE"
  echo "REASON=project_root_not_found"
  exit 10
}

if [[ ! -f "./gradlew" ]]; then
  echo "RESULT=ERROR"
  echo "STEP=PREPARE"
  echo "REASON=gradlew_not_found"
  exit 11
fi

if [[ ! -x "./gradlew" ]]; then
  chmod +x ./gradlew 2>/dev/null || true
fi

LOG_FILE="$(mktemp 2>/dev/null || printf '%s' "${TMPDIR:-/tmp}/focused-android-build.$$.log")"
cleanup() { rm -f "$LOG_FILE" 2>/dev/null || true; }
trap cleanup EXIT

./gradlew --console=plain "$GRADLE_TASK" >"$LOG_FILE" 2>&1
BUILD_STATUS=$?

if [[ $BUILD_STATUS -ne 0 ]]; then
  echo "RESULT=ERROR"
  echo "STEP=BUILD"
  echo "EXIT_CODE=$BUILD_STATUS"
  echo "LOG_LAST_100_BEGIN"
  tail -n 100 "$LOG_FILE"
  echo "LOG_LAST_100_END"
  exit 20
fi

APK_PATH=""
while IFS= read -r -d '' candidate; do
  if [[ -z "$APK_PATH" || "$candidate" -nt "$APK_PATH" ]]; then
    APK_PATH="$candidate"
  fi
done < <(find . -type f \( -path '*/build/outputs/apk/debug/*.apk' -o -path '*/build/outputs/apk/*/debug/*.apk' \) -print0 2>/dev/null)

if [[ -z "$APK_PATH" || ! -f "$APK_PATH" ]]; then
  echo "RESULT=ERROR"
  echo "STEP=LOCATE_APK"
  echo "REASON=debug_apk_not_found"
  exit 21
fi

if [[ "$MODE" == "build-only" ]]; then
  echo "RESULT=OK"
  echo "BUILD=SUCCESS"
  echo "INSTALL=SKIPPED"
  echo "APK=$APK_PATH"
  exit 0
fi

if ! command -v adb >/dev/null 2>&1; then
  echo "RESULT=ERROR"
  echo "STEP=INSTALL"
  echo "BUILD=SUCCESS"
  echo "APK=$APK_PATH"
  echo "REASON=adb_not_found"
  exit 30
fi

ADB_STATE="$(adb get-state 2>/dev/null || true)"
if [[ "$ADB_STATE" != "device" ]]; then
  echo "RESULT=ERROR"
  echo "STEP=INSTALL"
  echo "BUILD=SUCCESS"
  echo "APK=$APK_PATH"
  echo "REASON=adb_device_not_ready"
  echo "ADB_STATE=${ADB_STATE:-unknown}"
  exit 31
fi

INSTALL_OUTPUT="$(adb install -r "$APK_PATH" 2>&1)"
INSTALL_STATUS=$?
if [[ $INSTALL_STATUS -ne 0 ]] || ! grep -q "Success" <<<"$INSTALL_OUTPUT"; then
  echo "RESULT=ERROR"
  echo "STEP=INSTALL"
  echo "BUILD=SUCCESS"
  echo "APK=$APK_PATH"
  echo "EXIT_CODE=$INSTALL_STATUS"
  echo "INSTALL_OUTPUT_BEGIN"
  printf '%s\n' "$INSTALL_OUTPUT" | tail -n 100
  echo "INSTALL_OUTPUT_END"
  exit 32
fi

echo "RESULT=OK"
echo "BUILD=SUCCESS"
echo "INSTALL=SUCCESS"
echo "APK=$APK_PATH"
