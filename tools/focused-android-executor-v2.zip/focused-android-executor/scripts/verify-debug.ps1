param(
    [string]$ProjectRoot = (Get-Location).Path,
    [ValidateSet("install", "build-only")]
    [string]$Mode = "install",
    [string]$GradleTask = "assembleDebug"
)

$ErrorActionPreference = "Stop"
Set-Location $ProjectRoot

if (-not (Test-Path ".\gradlew.bat")) {
    Write-Output "RESULT=ERROR"
    Write-Output "STEP=PREPARE"
    Write-Output "REASON=gradlew_bat_not_found"
    exit 11
}

$logFile = Join-Path $env:TEMP ("focused-android-build-{0}.log" -f $PID)
try {
    & .\gradlew.bat --console=plain $GradleTask *> $logFile
    $buildStatus = $LASTEXITCODE

    if ($buildStatus -ne 0) {
        Write-Output "RESULT=ERROR"
        Write-Output "STEP=BUILD"
        Write-Output "EXIT_CODE=$buildStatus"
        Write-Output "LOG_LAST_100_BEGIN"
        Get-Content $logFile -Tail 100
        Write-Output "LOG_LAST_100_END"
        exit 20
    }

    $apk = Get-ChildItem -Path . -Recurse -File -Filter *.apk |
        Where-Object { $_.FullName -match "build[\\/]outputs[\\/]apk.*[\\/]debug[\\/]" } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if (-not $apk) {
        Write-Output "RESULT=ERROR"
        Write-Output "STEP=LOCATE_APK"
        Write-Output "REASON=debug_apk_not_found"
        exit 21
    }

    if ($Mode -eq "build-only") {
        Write-Output "RESULT=OK"
        Write-Output "BUILD=SUCCESS"
        Write-Output "INSTALL=SKIPPED"
        Write-Output "APK=$($apk.FullName)"
        exit 0
    }

    if (-not (Get-Command adb -ErrorAction SilentlyContinue)) {
        Write-Output "RESULT=ERROR"
        Write-Output "STEP=INSTALL"
        Write-Output "BUILD=SUCCESS"
        Write-Output "APK=$($apk.FullName)"
        Write-Output "REASON=adb_not_found"
        exit 30
    }

    $adbState = (& adb get-state 2>$null)
    if ($adbState -ne "device") {
        Write-Output "RESULT=ERROR"
        Write-Output "STEP=INSTALL"
        Write-Output "BUILD=SUCCESS"
        Write-Output "APK=$($apk.FullName)"
        Write-Output "REASON=adb_device_not_ready"
        Write-Output "ADB_STATE=$adbState"
        exit 31
    }

    $installOutput = (& adb install -r $apk.FullName 2>&1 | Out-String)
    $installStatus = $LASTEXITCODE
    if ($installStatus -ne 0 -or $installOutput -notmatch "Success") {
        Write-Output "RESULT=ERROR"
        Write-Output "STEP=INSTALL"
        Write-Output "BUILD=SUCCESS"
        Write-Output "APK=$($apk.FullName)"
        Write-Output "EXIT_CODE=$installStatus"
        Write-Output "INSTALL_OUTPUT_BEGIN"
        ($installOutput -split "`r?`n") | Select-Object -Last 100
        Write-Output "INSTALL_OUTPUT_END"
        exit 32
    }

    Write-Output "RESULT=OK"
    Write-Output "BUILD=SUCCESS"
    Write-Output "INSTALL=SUCCESS"
    Write-Output "APK=$($apk.FullName)"
}
finally {
    Remove-Item $logFile -ErrorAction SilentlyContinue
}
